plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.reehbalak.smartconfig"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.reehbalak.smartconfig"
        minSdk = 29
        targetSdk = 34
        versionCode = 1
        versionName = "0.2.0"
    }
    buildTypes { release { isMinifyEnabled = false } }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
    buildFeatures { compose = true }
    composeOptions { kotlinCompilerExtensionVersion = "1.5.10" }
    testOptions { unitTests.isReturnDefaultValues = true }
    packaging { resources { excludes += setOf("/META-INF/{AL2.0,LGPL2.1}", "/META-INF/versions/**") } }
}

dependencies {
    implementation(platform("androidx.compose:compose-bom:2024.02.00"))
    implementation("androidx.compose.ui:ui")
    implementation("androidx.compose.material3:material3")
    implementation("androidx.activity:activity-compose:1.8.2")
    implementation("androidx.lifecycle:lifecycle-viewmodel-compose:2.7.0")
    // SSH (يدعم الخوارزميات الحديثة التي تستعملها OpenWrt)
    implementation("com.github.mwiede:jsch:0.2.17")
    // مطلوب لمفاتيح ed25519 على Android 10
    implementation("org.bouncycastle:bcprov-jdk18on:1.77")

    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.7.3")

    testImplementation("junit:junit:4.13.2")
    testImplementation("org.json:json:20240303")
}
