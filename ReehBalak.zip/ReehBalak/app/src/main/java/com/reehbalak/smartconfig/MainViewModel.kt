package com.reehbalak.smartconfig

import android.app.Application
import android.net.Uri
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.reehbalak.smartconfig.core.Backup
import com.reehbalak.smartconfig.core.Compat
import com.reehbalak.smartconfig.core.CompatResult
import com.reehbalak.smartconfig.core.Level
import com.reehbalak.smartconfig.core.Plan
import com.reehbalak.smartconfig.core.PlanEngine
import com.reehbalak.smartconfig.core.Sanitizer
import com.reehbalak.smartconfig.core.SUPPORTED_PACKAGES
import com.reehbalak.smartconfig.core.Template
import com.reehbalak.smartconfig.core.UciPackage
import com.reehbalak.smartconfig.core.UciSection
import com.reehbalak.smartconfig.ops.ApplyReport
import com.reehbalak.smartconfig.ops.Found
import com.reehbalak.smartconfig.ops.Json
import com.reehbalak.smartconfig.ops.NetScan
import com.reehbalak.smartconfig.ops.Programmer
import com.reehbalak.smartconfig.ops.Store
import com.reehbalak.smartconfig.ssh.ConnectResult
import com.reehbalak.smartconfig.ssh.Creds
import com.reehbalak.smartconfig.ssh.DeviceInfo
import com.reehbalak.smartconfig.ssh.HostKeyInfo
import com.reehbalak.smartconfig.ssh.HostKeyStore
import com.reehbalak.smartconfig.ssh.SshService
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.util.UUID

enum class Screen {
    Home, Discover, Connect, Info, ReadSettings, Select, Templates,
    Auto, Preview, Result, Backups, Log, AppSettings
}

data class Editor(
    val name: String,
    val editingId: String?,
    val base: Template?,
    val raw: Map<String, UciPackage>?,
    val includeSecrets: Boolean,
    val selected: Set<String>,
)

data class PlanState(
    val template: Template,
    val plan: Plan,
    val compat: CompatResult,
    val selectedPkgs: Set<String>,
    val confirmCut: Boolean = false,
    val confirmBoard: Boolean = false,
)

data class UiState(
    val screen: Screen = Screen.Home,
    val busy: Boolean = false,
    val busyMsg: String = "",
    val error: String? = null,
    val message: String? = null,
    val prefillHost: String = "192.168.1.1",
    val unknownKey: HostKeyInfo? = null,
    val keyChanged: Pair<String, String>? = null,
    val info: DeviceInfo? = null,
    val connectedHost: String? = null,
    val snapshot: Map<String, UciPackage>? = null,
    val templates: List<Template> = emptyList(),
    val backups: List<Backup> = emptyList(),
    val log: List<String> = emptyList(),
    val found: List<Found> = emptyList(),
    val scanned: Boolean = false,
    val editor: Editor? = null,
    val planState: PlanState? = null,
    val report: ApplyReport? = null,
    val autoMode: Boolean = false,
)

fun editorSource(e: Editor): Pair<Map<String, List<UciSection>>, List<String>> {
    if (e.base != null) return e.base.packages to emptyList()
    val out = LinkedHashMap<String, List<UciSection>>()
    val notes = ArrayList<String>()
    for ((p, pk) in e.raw ?: emptyMap()) {
        val r = Sanitizer.clean(p, pk.sections, e.includeSecrets)
        if (r.sections.isNotEmpty()) out[p] = r.sections
        notes.addAll(r.notes)
    }
    return out to notes
}

private fun safeFile(name: String) = name.replace(Regex("[^\\p{L}\\p{N}_-]"), "_") + ".reehbalak.json"

class MainViewModel(app: Application) : AndroidViewModel(app) {
    private val store = Store(app)
    private val service = SshService(HostKeyStore(app))
    private val prog = Programmer(service, store)

    var state by mutableStateOf(UiState())
        private set

    private var pending: Creds? = null   // أثناء تأكيد البصمة
    private var session: Creds? = null   // في الذاكرة فقط، لا تُحفظ
    private var exportText = ""

    val isConnected: Boolean get() = session != null

    init {
        state = state.copy(autoMode = store.autoMode)
        refresh()
    }

    private fun refresh() {
        state = state.copy(templates = store.templates(), backups = store.backups(), log = store.readLog())
    }

    private fun log(s: String) { store.log(s); state = state.copy(log = store.readLog()) }

    private fun work(msg: String, block: suspend () -> Unit) {
        state = state.copy(busy = true, busyMsg = msg, error = null, message = null)
        viewModelScope.launch {
            try {
                block()
            } catch (e: Exception) {
                log("خطأ: ${e.message}")
                state = state.copy(error = e.message ?: "خطأ غير متوقع")
            } finally {
                state = state.copy(busy = false, busyMsg = "")
            }
        }
    }

    private fun progress(): (String) -> Unit = { m -> viewModelScope.launch { state = state.copy(busyMsg = m) } }

    // ---------- تنقل ----------
    fun go(s: Screen) { state = state.copy(screen = s, error = null, message = null) }
    fun clearMsg() { state = state.copy(error = null, message = null) }

    fun back() {
        val s = state.screen
        val next = when (s) {
            Screen.Home -> Screen.Home
            Screen.Result -> if (isConnected) Screen.Info else Screen.Home
            Screen.Preview -> Screen.Auto
            Screen.Auto, Screen.ReadSettings -> Screen.Info
            Screen.Select -> if (state.editor?.editingId == null) Screen.ReadSettings else Screen.Templates
            else -> Screen.Home
        }
        go(next)
    }

    fun disconnect() {
        session = null
        state = state.copy(info = null, connectedHost = null, snapshot = null, planState = null,
            report = null, editor = null, screen = Screen.Home)
        log("قُطع الاتصال وحُذفت بيانات الدخول من الذاكرة")
    }

    // ---------- اكتشاف ----------
    fun scan() {
        val prefix = NetScan.localPrefix(getApplication())
        if (prefix == null) { state = state.copy(error = "الهاتف غير متصل بشبكة Wi-Fi"); return }
        work("جارٍ فحص $prefix.0/24 (المنفذ 22)…") {
            val f = NetScan.scan(prefix)
            log("الفحص وجد ${f.size} جهاز SSH في $prefix.0/24")
            state = state.copy(found = f, scanned = true)
        }
    }

    fun pick(ip: String) { state = state.copy(prefillHost = ip, screen = Screen.Connect) }

    // ---------- اتصال ----------
    fun connect(host: String, portText: String, user: String, pass: String) {
        val h = host.trim()
        val p = portText.trim().toIntOrNull()
        if (h.isEmpty() || p == null || p !in 1..65535 || user.isBlank() || pass.isEmpty()) {
            state = state.copy(error = "تحقق من العنوان والمنفذ واسم المستخدم وكلمة المرور")
            return
        }
        pending = Creds(h, p, user.trim(), pass)
        doConnect()
    }

    private fun doConnect() {
        val c = pending ?: return
        work("جارٍ الاتصال…") {
            val r = withContext(Dispatchers.IO) { service.probe(c.host, c.port, c.user, c.pass) }
            val tag = "${c.host}:${c.port}"
            when (r) {
                is ConnectResult.Success -> {
                    session = c
                    pending = null
                    log("اتصال ناجح بـ $tag (${r.info.model})")
                    state = state.copy(info = r.info, connectedHost = c.host, screen = Screen.Info)
                }
                is ConnectResult.UnknownKey -> state = state.copy(unknownKey = r.key)
                is ConnectResult.KeyChanged -> {
                    log("تحذير: تغيّرت بصمة $tag")
                    state = state.copy(keyChanged = r.expected to r.actual)
                }
                is ConnectResult.Failure -> {
                    pending = null
                    log("فشل الاتصال بـ $tag: ${r.message}")
                    state = state.copy(error = r.message)
                }
            }
        }
    }

    fun trustAndRetry() {
        val c = pending ?: return
        val k = state.unknownKey ?: return
        service.trust(c.host, c.port, k.fingerprint)
        log("وُثقت بصمة ${c.host}:${c.port}")
        state = state.copy(unknownKey = null)
        doConnect()
    }

    fun replaceKeyAndRetry() {
        val c = pending ?: return
        val k = state.keyChanged ?: return
        service.trust(c.host, c.port, k.second)
        log("استُبدلت بصمة ${c.host}:${c.port} بقرار المستخدم")
        state = state.copy(keyChanged = null)
        doConnect()
    }

    fun dismissDialog() {
        pending = null
        state = state.copy(unknownKey = null, keyChanged = null)
    }

    // ---------- قراءة الإعدادات والقوالب ----------
    fun readSettings() {
        val c = session ?: return
        work("جارٍ قراءة الإعدادات…") {
            val pk = withContext(Dispatchers.IO) { prog.withConn(c) { prog.readPackages(it) } }
            log("قُرئت ${pk.size} حزم إعدادات")
            state = state.copy(snapshot = pk, screen = Screen.ReadSettings)
        }
    }

    fun startCreate() {
        val raw = state.snapshot ?: return
        val info = state.info ?: return
        val e = Editor("قالب ${info.model.ifBlank { info.boardName }}", null, null, raw, false, emptySet())
        val (src, _) = editorSource(e)
        val all = src.flatMap { (p, l) -> l.map { "$p|${it.key}" } }.toSet()
        state = state.copy(editor = e.copy(selected = all), screen = Screen.Select)
    }

    fun setEditorName(n: String) { state.editor?.let { state = state.copy(editor = it.copy(name = n)) } }

    fun setEditorSecrets(b: Boolean) {
        val e = state.editor ?: return
        val updated = e.copy(includeSecrets = b)
        val (src, _) = editorSource(updated)
        val valid = src.flatMap { (p, l) -> l.map { "$p|${it.key}" } }.toSet()
        // الأقسام الجديدة (الكاشفة للأسرار) تُحدَّد تلقائيًا كما كانت محددة
        state = state.copy(editor = updated.copy(selected = e.selected.filter { it in valid }.toSet()))
    }

    fun toggleSection(id: String) {
        val e = state.editor ?: return
        state = state.copy(editor = e.copy(selected = if (id in e.selected) e.selected - id else e.selected + id))
    }

    fun toggleAll(pkg: String, keys: List<String>, on: Boolean) {
        val e = state.editor ?: return
        val ids = keys.map { "$pkg|$it" }.toSet()
        state = state.copy(editor = e.copy(selected = if (on) e.selected + ids else e.selected - ids))
    }

    fun saveEditor() {
        val e = state.editor ?: return
        val info = state.info
        if (e.name.isBlank()) { state = state.copy(error = "اكتب اسمًا للقالب"); return }
        val (src, _) = editorSource(e)
        val chosen = LinkedHashMap<String, List<UciSection>>()
        for ((p, l) in src) {
            val keep = l.filter { "$p|${it.key}" in e.selected }
            if (keep.isNotEmpty()) chosen[p] = keep
        }
        if (chosen.isEmpty()) { state = state.copy(error = "اختر إعدادًا واحدًا على الأقل"); return }
        val now = System.currentTimeMillis()
        val t = if (e.base != null) {
            e.base.copy(name = e.name.trim(), updatedAt = now, packages = chosen)
        } else {
            Template(UUID.randomUUID().toString(), e.name.trim(), now, now,
                info?.boardName ?: "", info?.model ?: "", info?.distribution ?: "", info?.version ?: "",
                e.includeSecrets, chosen)
        }
        store.saveTemplate(t)
        log("حُفظ القالب «${t.name}»")
        refresh()
        state = state.copy(editor = null, screen = Screen.Templates, message = "حُفظ القالب")
    }

    fun editTemplate(t: Template) {
        val all = t.packages.flatMap { (p, l) -> l.map { "$p|${it.key}" } }.toSet()
        state = state.copy(editor = Editor(t.name, t.id, t, null, t.includesSecrets, all), screen = Screen.Select)
    }

    fun duplicateTemplate(t: Template) {
        val now = System.currentTimeMillis()
        store.saveTemplate(t.copy(id = UUID.randomUUID().toString(), name = t.name + " (نسخة)",
            createdAt = now, updatedAt = now))
        refresh()
    }

    fun deleteTemplate(t: Template) { store.deleteTemplate(t.id); log("حُذف القالب «${t.name}»"); refresh() }

    // ---------- تصدير واستيراد ----------
    fun exportTemplate(t: Template): String { exportText = Json.toJson(t).toString(2); return safeFile(t.name) }
    fun exportBackup(b: Backup): String { exportText = Json.toJson(b).toString(2); return safeFile("backup_${b.hostname}") }

    fun exportTo(uri: Uri) {
        try {
            getApplication<Application>().contentResolver.openOutputStream(uri)?.use {
                it.write(exportText.toByteArray(Charsets.UTF_8))
            }
            state = state.copy(message = "تم التصدير")
            log("تصدير ملف")
        } catch (e: Exception) {
            state = state.copy(error = "فشل التصدير: ${e.message}")
        }
        exportText = ""
    }

    fun importFile(uri: Uri) = work("جارٍ الاستيراد…") {
        val text = withContext(Dispatchers.IO) {
            getApplication<Application>().contentResolver.openInputStream(uri)?.use { it.readBytes() }
                ?: throw IllegalStateException("تعذرت قراءة الملف")
        }
        check(text.size < 5_000_000) { "الملف كبير جدًا" }
        val o = JSONObject(text.toString(Charsets.UTF_8))
        when (o.optString("kind")) {
            "template" -> {
                val t = Json.template(o).copy(id = UUID.randomUUID().toString())
                store.saveTemplate(t)
                log("استُورد القالب «${t.name}»")
                state = state.copy(message = "استُورد القالب «${t.name}»")
            }
            "backup" -> {
                val b = Json.backup(o).copy(id = UUID.randomUUID().toString())
                check(b.intact) { "النسخة الاحتياطية تالفة أو معدّلة (فشل SHA-256)" }
                store.saveBackup(b)
                log("استُوردت نسخة احتياطية لـ ${b.hostname}")
                state = state.copy(message = "استُوردت النسخة الاحتياطية")
            }
            else -> throw IllegalStateException("ملف غير معروف")
        }
        refresh()
    }

    // ---------- برمجة تلقائية ----------
    fun openAuto() { if (session != null && state.info != null) go(Screen.Auto) }

    fun chooseTemplate(t: Template) {
        val c = session ?: return
        val info = state.info ?: return
        work("جارٍ مقارنة القالب بالجهاز…") {
            val dev = withContext(Dispatchers.IO) {
                prog.withConn(c) { prog.readPackages(it, t.packages.keys.toList()) }
            }
            val plan = PlanEngine.build(t.packages, dev)
            val compat = Compat.check(t, info)
            log("مقارنة «${t.name}»: ${plan.sections.size} قسم بتغييرات، ${plan.conflicts.size} تعارض")
            val ps = PlanState(t, plan, compat, plan.packages.toSet())
            state = state.copy(planState = ps, screen = Screen.Preview)
            if (state.autoMode && compat.level == Level.OK && plan.conflicts.isEmpty() && plan.sections.isNotEmpty()) {
                log("وضع التشغيل التلقائي: تطبيق دون معاينة (النسخ الاحتياطي والتحقق مفعّلان)")
                applyNow(ps)
            }
        }
    }

    fun togglePkg(p: String) {
        val ps = state.planState ?: return
        state = state.copy(planState = ps.copy(
            selectedPkgs = if (p in ps.selectedPkgs) ps.selectedPkgs - p else ps.selectedPkgs + p))
    }
    fun setConfirmCut(b: Boolean) { state.planState?.let { state = state.copy(planState = it.copy(confirmCut = b)) } }
    fun setConfirmBoard(b: Boolean) { state.planState?.let { state = state.copy(planState = it.copy(confirmBoard = b)) } }

    fun applyPlan() {
        val ps = state.planState ?: return
        work("جارٍ التطبيق…") { applyNow(ps) }
    }

    private suspend fun applyNow(ps: PlanState) {
        val c = session ?: return
        val info = state.info ?: return
        val rep = withContext(Dispatchers.IO) { prog.apply(c, info, ps.plan, ps.selectedPkgs, progress()) }
        rep.connectedHost?.let { session = c.copy(host = it); state = state.copy(connectedHost = it) }
        log(rep.title)
        refresh()
        state = state.copy(report = rep, screen = Screen.Result)
    }

    // ---------- نسخ احتياطي ----------
    fun backupNow() {
        val c = session ?: return
        val info = state.info ?: return
        work("جارٍ أخذ نسخة احتياطية…") {
            withContext(Dispatchers.IO) { prog.makeBackup(c, info, SUPPORTED_PACKAGES) }
            refresh()
            state = state.copy(message = "حُفظت نسخة احتياطية على الهاتف")
        }
    }

    fun restore(b: Backup) {
        val c = session ?: return
        val info = state.info ?: return
        work("جارٍ الاستعادة…") {
            val rep = withContext(Dispatchers.IO) { prog.restore(c, info, b, progress()) }
            rep.connectedHost?.let { session = c.copy(host = it); state = state.copy(connectedHost = it) }
            log(rep.title)
            state = state.copy(report = rep, screen = Screen.Result)
        }
    }

    fun deleteBackup(b: Backup) { store.deleteBackup(b.id); log("حُذفت نسخة ${b.hostname}"); refresh() }

    // ---------- إعدادات وسجل ----------
    fun setAutoMode(on: Boolean) { store.autoMode = on; state = state.copy(autoMode = on) }
    fun clearLog() { store.clearLog(); refresh() }
}
