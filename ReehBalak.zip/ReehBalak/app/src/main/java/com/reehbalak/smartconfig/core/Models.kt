package com.reehbalak.smartconfig.core

import com.reehbalak.smartconfig.ssh.DeviceInfo
import java.security.MessageDigest

val SUPPORTED_PACKAGES = listOf("network", "wireless", "dhcp", "firewall", "system", "dropbear", "uhttpd")

val GROUP_TITLES = mapOf(
    "network" to "الشبكة: LAN وWAN والتوجيه وDNS وVLAN",
    "wireless" to "Wi-Fi: الأسماء والقنوات والتشفير",
    "dhcp" to "DHCP وDNS",
    "firewall" to "الجدار الناري والمنافذ",
    "system" to "النظام",
    "dropbear" to "SSH (dropbear)",
    "uhttpd" to "واجهة الويب (uhttpd)",
)

data class Template(
    val id: String,
    val name: String,
    val createdAt: Long,
    val updatedAt: Long,
    val board: String,
    val model: String,
    val distribution: String,
    val version: String,
    val includesSecrets: Boolean,
    val packages: Map<String, List<UciSection>>,
)

data class Backup(
    val id: String,
    val host: String,
    val hostname: String,
    val board: String,
    val model: String,
    val version: String,
    val createdAt: Long,
    val packages: Map<String, String>,
    val sha256: String,
) {
    val intact: Boolean get() = hash(packages) == sha256

    companion object {
        fun hash(p: Map<String, String>): String {
            val canonical = p.toSortedMap().entries.joinToString("\u0000") { "${it.key}\u0001${it.value}" }
            return MessageDigest.getInstance("SHA-256").digest(canonical.toByteArray(Charsets.UTF_8))
                .joinToString("") { "%02x".format(it) }
        }

        fun create(id: String, host: String, info: DeviceInfo, packages: Map<String, String>,
                   now: Long = System.currentTimeMillis()) =
            Backup(id, host, info.hostname, info.boardName, info.model, info.version, now, packages, hash(packages))
    }
}

enum class Level { OK, WARN, BLOCK }
data class CompatResult(val level: Level, val notes: List<String>)

object Compat {
    private fun series(v: String) = v.split(".").take(2).joinToString(".")

    fun check(t: Template, i: DeviceInfo): CompatResult {
        val notes = ArrayList<String>()
        var level = Level.OK
        fun warn(msg: String) { notes.add(msg); if (level == Level.OK) level = Level.WARN }
        if (!i.hasUci) { notes.add("الجهاز لا يحتوي أداة uci"); level = Level.BLOCK }
        if (!i.isRoot) { notes.add("الحساب ليس root، لا يمكن التعديل"); level = Level.BLOCK }
        if (t.board.isNotBlank() && t.board != i.boardName)
            warn("لوحة مختلفة: القالب «${t.board}» والجهاز «${i.boardName}»")
        if (t.version.isNotBlank() && series(t.version) != series(i.version))
            warn("إصدار مختلف: القالب ${t.version} والجهاز ${i.version}")
        if (!i.distribution.equals(t.distribution, ignoreCase = true))
            warn("توزيعة مختلفة: «${t.distribution}» مقابل «${i.distribution}»")
        if (notes.isEmpty()) notes.add("متوافق: نفس الطراز والإصدار")
        return CompatResult(level, notes)
    }
}
