package com.reehbalak.smartconfig.core

data class Change(
    val option: String,
    val oldValue: String?,
    val newValue: String,
    val isList: Boolean,
    val newList: List<String>,
)

data class PlanSection(
    val pkg: String,
    val section: UciSection,
    val targetAddr: String?,
    val isNew: Boolean,
    val changes: List<Change>,
)

data class Conflict(val pkg: String, val label: String, val reason: String)

data class Plan(
    val sections: List<PlanSection>,
    val conflicts: List<Conflict>,
    val warnings: List<String>,
) {
    val packages: List<String> get() = sections.map { it.pkg }.distinct()
}

object PlanEngine {
    private val IDENT = Regex("^[A-Za-z0-9_-]+$")
    private val CUT_NET = setOf("ipaddr", "netmask", "proto", "gateway", "ip6addr")

    private fun addr(pkg: String, d: UciSection, dp: UciPackage): String =
        if (d.name != null) "$pkg.${d.name}"
        else "$pkg.@${d.type}[${dp.sections.filter { it.type == d.type }.indexOf(d)}]"

    private fun radioProblem(s: UciSection, devRadios: Map<String?, UciSection>): String? {
        val d = devRadios[s.name] ?: return "الراديو غير موجود على هذا الجهاز"
        for (k in listOf("band", "hwmode")) {
            val t = s.options[k]
            val v = d.options[k]
            if (t != null && v != null && t != v) return "نطاق الراديو مختلف ($t مقابل $v)"
        }
        return null
    }

    private fun validIdents(s: UciSection): Boolean =
        IDENT.matches(s.type) &&
            (s.name == null || IDENT.matches(s.name)) &&
            s.options.keys.all { IDENT.matches(it) } &&
            s.lists.keys.all { IDENT.matches(it) }

    fun build(tpl: Map<String, List<UciSection>>, dev: Map<String, UciPackage>): Plan {
        val ps = ArrayList<PlanSection>()
        val cs = ArrayList<Conflict>()
        val ws = LinkedHashSet<String>()

        val devRadios: Map<String?, UciSection> =
            dev["wireless"]?.sections?.filter { it.type == "wifi-device" }?.associateBy { it.name } ?: emptyMap()
        val badRadios = HashSet<String?>()
        tpl["wireless"]?.filter { it.type == "wifi-device" }?.forEach {
            if (radioProblem(it, devRadios) != null) badRadios.add(it.name)
        }

        for ((pkg, secs) in tpl) {
            if (pkg !in SUPPORTED_PACKAGES) { cs.add(Conflict(pkg, "*", "حزمة غير مدعومة")); continue }
            val dp = dev[pkg]
            if (dp == null) { cs.add(Conflict(pkg, "*", "الحزمة غير موجودة على الجهاز")); continue }
            val byKey = dp.sections.associateBy { it.key }

            for (s in secs) {
                if (!validIdents(s)) { cs.add(Conflict(pkg, s.label, "اسم غير صالح في القالب")); continue }

                if (pkg == "wireless" && s.type == "wifi-device") {
                    val problem = radioProblem(s, devRadios)
                    if (problem != null) { cs.add(Conflict(pkg, s.label, problem)); continue }
                }
                if (pkg == "wireless" && s.type == "wifi-iface") {
                    val radio = s.options["device"]
                    val radioOk = radio == null || (devRadios.containsKey(radio) && radio !in badRadios)
                    if (!radioOk) { cs.add(Conflict(pkg, s.label, "الراديو $radio غير متاح على هذا الجهاز")); continue }
                }

                val d = byKey[s.key]
                val changes = ArrayList<Change>()
                for ((k, v) in s.options) {
                    val old = d?.options?.get(k)
                    if (old != v) changes.add(Change(k, old, v, false, emptyList()))
                }
                for ((k, vs) in s.lists) {
                    val old = d?.lists?.get(k)
                    if (old != vs) changes.add(Change(k, old?.joinToString(", "), vs.joinToString(", "), true, vs))
                }
                if (d != null && changes.isEmpty()) continue
                ps.add(PlanSection(pkg, s, if (d == null) null else addr(pkg, d, dp), d == null, changes))
            }
        }

        for (p in ps) {
            when (p.pkg) {
                "network" -> if (p.changes.any { it.option in CUT_NET })
                    ws.add("تغيير عنوان IP أو البروتوكول قد يقطع الاتصال بالجهاز")
                "wireless" -> ws.add("تغيير Wi-Fi سيفصل الأجهزة المتصلة لاسلكيًا ويعيد تشغيل الشبكة اللاسلكية")
                "dropbear" -> ws.add("تغيير إعدادات SSH قد يقطع الاتصال")
                "firewall" -> ws.add("تعديل الجدار الناري قد يغيّر صلاحيات الوصول للجهاز")
            }
        }
        return Plan(ps, cs, ws.toList())
    }

    /** عنوان LAN الجديد إن كانت الخطة تغيّره (للاتصال به بعد التطبيق). */
    fun newLanIp(sections: List<PlanSection>): String? {
        val s = sections.firstOrNull { it.pkg == "network" && it.section.name == "lan" } ?: return null
        val c = s.changes.firstOrNull { it.option == "ipaddr" } ?: return null
        val v = if (c.isList) c.newList.firstOrNull() else c.newValue
        return v?.substringBefore("/")?.takeIf { it.isNotBlank() }
    }

    /** يعيد قائمة بالاختلافات بعد التطبيق (فارغة = نجاح). */
    fun verify(applied: List<PlanSection>, after: Map<String, UciPackage>): List<String> {
        val bad = ArrayList<String>()
        for (ps in applied) {
            val pk = after[ps.pkg]
            if (pk == null) { bad.add("${ps.pkg}: الحزمة غير موجودة"); continue }
            fun matches(d: UciSection) = ps.changes.all { c ->
                if (c.isList) d.lists[c.option] == c.newList else d.options[c.option] == c.newValue
            }
            val ok = if (ps.isNew && ps.section.name == null) {
                pk.sections.any { it.type == ps.section.type && it.name == null && matches(it) }
            } else {
                val d = pk.sections.firstOrNull { it.key == ps.section.key }
                d != null && matches(d)
            }
            if (!ok) bad.add("${ps.pkg}: ${ps.section.label} لم تُطبَّق كما هو مطلوب")
        }
        return bad
    }
}

object CommandBuilder {
    fun shq(s: String) = "'" + s.replace("'", "'\\''") + "'"

    /** سكربت يُمرَّر إلى `sh -s`: يضبط ثم يحفظ (commit) عند نجاح كل شيء. */
    fun applyScript(sections: List<PlanSection>): String {
        val sb = StringBuilder("set -e\n")
        for (ps in sections) {
            val s = ps.section
            val addr: String
            if (ps.isNew) {
                if (s.name != null) {
                    sb.append("uci set ${ps.pkg}.${s.name}=${s.type}\n")
                    addr = "${ps.pkg}.${s.name}"
                } else {
                    sb.append("uci add ${ps.pkg} ${s.type} >/dev/null\n")
                    addr = "${ps.pkg}.@${s.type}[-1]"
                }
            } else {
                addr = ps.targetAddr ?: error("لا عنوان للقسم")
            }
            for (c in ps.changes) {
                if (c.isList) {
                    sb.append("uci -q delete $addr.${c.option} || true\n")
                    for (v in c.newList) sb.append("uci add_list $addr.${c.option}=${shq(v)}\n")
                } else {
                    sb.append("uci set $addr.${c.option}=${shq(c.newValue)}\n")
                }
            }
        }
        for (p in sections.map { it.pkg }.distinct()) sb.append("uci commit $p\n")
        return sb.toString()
    }

    private fun serviceCmds(pkgs: Set<String>): List<String> {
        val c = ArrayList<String>()
        if ("network" in pkgs) c.add("/etc/init.d/network reload")
        if ("wireless" in pkgs) c.add("wifi reload")
        if ("dhcp" in pkgs) { c.add("/etc/init.d/dnsmasq reload"); c.add("/etc/init.d/odhcpd reload") }
        if ("firewall" in pkgs) c.add("/etc/init.d/firewall reload")
        if ("system" in pkgs) c.add("/etc/init.d/system reload")
        if ("dropbear" in pkgs) c.add("/etc/init.d/dropbear reload")
        if ("uhttpd" in pkgs) c.add("/etc/init.d/uhttpd reload")
        return c
    }

    /** إعادة تحميل الخدمات في الخلفية حتى لا ينقطع أمر SSH نفسه. */
    fun reloadCommand(pkgs: Set<String>): String =
        "nohup sh -c 'sleep 2; ${serviceCmds(pkgs).joinToString("; ")}' >/dev/null 2>&1 &"

    /** سكربت يعمل على الراوتر: يتراجع بعد مهلة ما لم يظهر الملف /tmp/rb/ok. */
    fun rollbackScript(pkgs: List<String>, delaySec: Int): String {
        val restore = pkgs.joinToString("\n") { "uci import $it < /tmp/rb/$it.uci && uci commit $it" }
        val reload = serviceCmds(pkgs.toSet()).joinToString("\n")
        return "#!/bin/sh\nsleep $delaySec\n[ -f /tmp/rb/ok ] && exit 0\n$restore\n$reload\n"
    }

    /** تراجع فوري في الخلفية. */
    fun restoreCommand(pkgs: List<String>): String {
        val restore = pkgs.joinToString("; ") { "uci import $it < /tmp/rb/$it.uci && uci commit $it" }
        val reload = serviceCmds(pkgs.toSet()).joinToString("; ")
        return "nohup sh -c 'sleep 1; $restore; $reload' >/dev/null 2>&1 &"
    }
}
