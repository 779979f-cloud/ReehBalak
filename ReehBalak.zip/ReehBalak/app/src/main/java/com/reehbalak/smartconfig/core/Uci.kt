package com.reehbalak.smartconfig.core

data class UciSection(
    val type: String,
    val name: String?,
    val anonIndex: Int,
    val options: Map<String, String>,
    val lists: Map<String, List<String>>,
) {
    val key: String get() = name ?: "@$type#$anonIndex"
    val label: String get() = if (name != null) "$type '$name'" else "$type #${anonIndex + 1}"
}

data class UciPackage(val name: String, val sections: List<UciSection>)

object UciParser {
    fun tokenize(line: String): List<String> {
        val tokens = ArrayList<String>()
        val cur = StringBuilder()
        var has = false
        var i = 0
        while (i < line.length) {
            val c = line[i]
            if (c == '\'') {
                has = true
                i++
                while (i < line.length && line[i] != '\'') { cur.append(line[i]); i++ }
            } else if (c == '"') {
                has = true
                i++
                while (i < line.length && line[i] != '"') {
                    if (line[i] == '\\' && i + 1 < line.length) i++
                    cur.append(line[i])
                    i++
                }
            } else if (c == '\\' && i + 1 < line.length) {
                has = true
                i++
                cur.append(line[i])
            } else if (c.isWhitespace()) {
                if (has) { tokens.add(cur.toString()); cur.setLength(0); has = false }
            } else {
                has = true
                cur.append(c)
            }
            i++
        }
        if (has) tokens.add(cur.toString())
        return tokens
    }

    /** يحلل ناتج `uci export <pkg>`. */
    fun parse(pkg: String, text: String): UciPackage {
        val sections = ArrayList<UciSection>()
        val anonCount = HashMap<String, Int>()
        var type: String? = null
        var name: String? = null
        var opts = LinkedHashMap<String, String>()
        var lists = LinkedHashMap<String, MutableList<String>>()

        fun flush() {
            val t = type
            if (t != null) {
                var idx = 0
                if (name == null) {
                    idx = anonCount[t] ?: 0
                    anonCount[t] = idx + 1
                }
                sections.add(UciSection(t, name, idx, opts, lists))
            }
            type = null
            name = null
            opts = LinkedHashMap()
            lists = LinkedHashMap()
        }

        for (raw in text.lineSequence()) {
            val t = tokenize(raw.trim())
            if (t.isEmpty()) continue
            when (t[0]) {
                "config" -> { flush(); type = t.getOrNull(1); name = t.getOrNull(2) }
                "option" -> if (t.size >= 3 && type != null) opts[t[1]] = t[2]
                "list" -> if (t.size >= 3 && type != null) lists.getOrPut(t[1]) { ArrayList() }.add(t[2])
                else -> {}
            }
        }
        flush()
        return UciPackage(pkg, sections)
    }
}

data class SanitizeResult(val sections: List<UciSection>, val notes: List<String>)

/** يستبعد المعرّفات الفريدة والمفاتيح والخيارات المرتبطة بالعتاد، ويعزل الأسرار. */
object Sanitizer {
    /** تُستبعد دائمًا. */
    val ALWAYS_DROPPED = setOf(
        "macaddr", "hwaddr", "path", "phy",
        "private_key", "public_key", "preshared_key",
        "auth_secret", "acct_secret", "ula_prefix",
    )
    /** تُستبعد افتراضيًا وتُضمَّن فقط بطلب المستخدم. */
    val SECRET_OPTIONS = setOf("key", "sae_password", "password", "username")
    private val NETWORK_HARDWARE_OPTIONS = setOf("device", "ifname", "ports")
    private val HARDWARE_SECTION_TYPES = setOf("device", "switch", "switch_vlan", "switch_port")

    fun clean(pkg: String, sections: List<UciSection>, includeSecrets: Boolean): SanitizeResult {
        val out = ArrayList<UciSection>()
        val droppedSections = LinkedHashSet<String>()
        val droppedOptions = LinkedHashSet<String>()

        fun dropOption(k: String): Boolean =
            k in ALWAYS_DROPPED ||
                (pkg == "network" && k in NETWORK_HARDWARE_OPTIONS) ||
                (k in SECRET_OPTIONS && !includeSecrets)

        for (s in sections) {
            if (s.type.startsWith("wireguard_") || (pkg == "network" && s.type in HARDWARE_SECTION_TYPES)) {
                droppedSections.add(s.type)
                continue
            }
            val opts = LinkedHashMap<String, String>()
            for ((k, v) in s.options) { if (dropOption(k)) droppedOptions.add(k) else opts[k] = v }
            val lists = LinkedHashMap<String, List<String>>()
            for ((k, v) in s.lists) { if (dropOption(k)) droppedOptions.add(k) else lists[k] = v }
            out.add(s.copy(options = opts, lists = lists))
        }
        val notes = ArrayList<String>()
        if (droppedSections.isNotEmpty())
            notes.add("$pkg: أقسام مستبعدة (مرتبطة بالعتاد أو بمفاتيح): ${droppedSections.joinToString("، ")}")
        if (droppedOptions.isNotEmpty())
            notes.add("$pkg: خيارات مستبعدة: ${droppedOptions.joinToString("، ")}")
        return SanitizeResult(out, notes)
    }
}
