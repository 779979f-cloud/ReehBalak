package com.reehbalak.smartconfig.ops

import android.content.Context
import android.net.wifi.WifiManager
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import java.net.InetSocketAddress
import java.net.Socket

data class Found(val ip: String, val banner: String)

/** يفحص منفذ SSH (22) فقط داخل شبكة Wi-Fi الحالية، بطلب صريح من المستخدم. */
object NetScan {
    @Suppress("DEPRECATION")
    fun localPrefix(ctx: Context): String? {
        val wm = ctx.applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager
        val ip = wm.dhcpInfo?.ipAddress ?: 0
        if (ip == 0) return null
        return "${ip and 0xff}.${(ip shr 8) and 0xff}.${(ip shr 16) and 0xff}"
    }

    suspend fun scan(prefix: String): List<Found> = coroutineScope {
        (1..254).map { n -> async(Dispatchers.IO) { probe("$prefix.$n") } }.awaitAll().filterNotNull()
    }

    private fun probe(ip: String): Found? {
        val s = Socket()
        return try {
            s.connect(InetSocketAddress(ip, 22), 500)
            s.soTimeout = 800
            val banner = try { s.getInputStream().bufferedReader().readLine() ?: "" } catch (e: Exception) { "" }
            Found(ip, banner)
        } catch (e: Exception) {
            null
        } finally {
            try { s.close() } catch (e: Exception) { }
        }
    }
}
