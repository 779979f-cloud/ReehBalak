package com.reehbalak.smartconfig.ops

import com.reehbalak.smartconfig.core.Backup
import com.reehbalak.smartconfig.core.CommandBuilder
import com.reehbalak.smartconfig.core.Plan
import com.reehbalak.smartconfig.core.PlanEngine
import com.reehbalak.smartconfig.core.SUPPORTED_PACKAGES
import com.reehbalak.smartconfig.core.UciPackage
import com.reehbalak.smartconfig.core.UciParser
import com.reehbalak.smartconfig.ssh.Creds
import com.reehbalak.smartconfig.ssh.DeviceInfo
import com.reehbalak.smartconfig.ssh.Open
import com.reehbalak.smartconfig.ssh.SshConn
import com.reehbalak.smartconfig.ssh.SshService
import java.util.UUID

data class ApplyReport(
    val ok: Boolean,
    val title: String,
    val lines: List<String>,
    val manual: List<String>,
    val backupId: String?,
    val connectedHost: String?,
)

class Programmer(private val ssh: SshService, private val store: Store) {

    private fun connect(c: Creds, host: String = c.host): SshConn =
        when (val o = ssh.open(host, c.port, c.user, c.pass)) {
            is Open.Ok -> o.conn
            is Open.UnknownKey -> throw IllegalStateException("بصمة الجهاز غير موثوقة. أعد الاتصال من شاشة الاتصال")
            is Open.KeyChanged -> throw IllegalStateException("تغيّرت بصمة الجهاز. أعد الاتصال وتحقق")
            is Open.Failure -> throw IllegalStateException(o.message)
        }

    fun <T> withConn(c: Creds, block: (SshConn) -> T): T {
        val conn = connect(c)
        try { return block(conn) } finally { conn.close() }
    }

    fun readRaw(conn: SshConn, pkgs: List<String>): Map<String, String> {
        val m = LinkedHashMap<String, String>()
        for (p in pkgs) {
            if (p !in SUPPORTED_PACKAGES) continue
            val r = conn.exec("uci -q export $p")
            if (r.code == 0 && r.out.isNotBlank()) m[p] = r.out
        }
        return m
    }

    fun readPackages(conn: SshConn, pkgs: List<String> = SUPPORTED_PACKAGES): Map<String, UciPackage> =
        readRaw(conn, pkgs).mapValues { UciParser.parse(it.key, it.value) }

    fun makeBackup(c: Creds, info: DeviceInfo, pkgs: List<String>): Backup {
        val raw = withConn(c) { readRaw(it, pkgs) }
        check(raw.isNotEmpty()) { "لم يُقرأ أي إعداد من الجهاز" }
        val b = Backup.create(UUID.randomUUID().toString(), c.host, info, raw)
        store.saveBackup(b)
        store.log("نسخة احتياطية يدوية للجهاز ${info.hostname}")
        return b
    }

    private fun reconnect(c: Creds, hosts: List<String>): Pair<SshConn, String>? {
        repeat(15) {
            for (h in hosts) {
                when (val o = ssh.open(h, c.port, c.user, c.pass)) {
                    is Open.Ok -> return o.conn to h
                    is Open.UnknownKey ->
                        // عنوان جديد لنفس الجهاز: نثق به فقط إن تطابقت البصمة مع بصمة العنوان القديم
                        if (ssh.knownFingerprint(c.host, c.port) == o.key.fingerprint)
                            ssh.trust(h, c.port, o.key.fingerprint)
                    else -> {}
                }
            }
            Thread.sleep(4000)
        }
        return null
    }

    fun apply(c: Creds, info: DeviceInfo, plan: Plan, selected: Set<String>,
              progress: (String) -> Unit): ApplyReport {
        val lines = ArrayList<String>()
        fun say(s: String) { lines.add(s); progress(s); store.log(s) }

        val manual = plan.conflicts.map { "${it.pkg}: ${it.label} — ${it.reason}" }
        val chosen = plan.sections.filter { it.pkg in selected }
        if (chosen.isEmpty())
            return ApplyReport(true, "لا توجد تغييرات", listOf("الجهاز مطابق للقالب في المجموعات المختارة"),
                manual, null, null)
        val pkgs = chosen.map { it.pkg }.distinct()
        var backupId: String? = null
        var beforeApply = true

        try {
            val conn = connect(c)
            try {
                say("إنشاء نسخة احتياطية قبل التعديل")
                val raw = readRaw(conn, pkgs)
                check(raw.keys.containsAll(pkgs)) { "تعذرت قراءة بعض الحزم للنسخ الاحتياطي" }
                val b = Backup.create(UUID.randomUUID().toString(), c.host, info, raw)
                store.saveBackup(b)
                backupId = b.id
                say("حُفظت النسخة على الهاتف")

                check(conn.exec("mkdir -p /tmp/rb && rm -f /tmp/rb/ok").code == 0) { "تعذر تجهيز /tmp/rb على الجهاز" }
                for ((p, t) in raw) check(conn.exec("cat > /tmp/rb/$p.uci", t).code == 0) { "تعذر رفع النسخة للجهاز" }
                check(conn.exec("cat > /tmp/rb/rollback.sh", CommandBuilder.rollbackScript(pkgs, 150)).code == 0) {
                    "تعذر تجهيز التراجع التلقائي"
                }
                conn.exec("nohup sh /tmp/rb/rollback.sh >/dev/null 2>&1 &")
                say("فُعّل التراجع التلقائي: يعود الجهاز لإعداداته خلال 150 ثانية إن لم يتأكد النجاح")

                val r = conn.exec("sh -s", CommandBuilder.applyScript(chosen))
                if (r.code != 0) {
                    conn.exec("sh -s", pkgs.joinToString("\n") { "uci revert $it" })
                    conn.exec("touch /tmp/rb/ok")
                    say("فشل ضبط الإعدادات: ${r.err.trim()}")
                    return ApplyReport(false, "فشل التطبيق، لم يتغير شيء", lines,
                        manual + r.err.trim(), backupId, null)
                }
                beforeApply = false
                say("حُفظت الإعدادات الجديدة، جارٍ إعادة تحميل الخدمات")
                conn.exec(CommandBuilder.reloadCommand(pkgs.toSet()))
            } finally {
                conn.close()
            }

            Thread.sleep(8000)
            val hosts = (listOf(c.host) + listOfNotNull(PlanEngine.newLanIp(chosen))).distinct()
            say("إعادة الاتصال بالجهاز…")
            val re = reconnect(c, hosts)
            if (re == null) {
                say("لم يستجب الجهاز. سيتراجع تلقائيًا للإعدادات السابقة خلال دقيقتين")
                return ApplyReport(false, "فُقد الاتصال بعد التطبيق", lines,
                    manual + "إن بقي الجهاز غير متاح بعد دقيقتين، أعد تشغيله أو استعد النسخة يدويًا", backupId, null)
            }
            val (conn2, host2) = re
            try {
                val after = readPackages(conn2, pkgs)
                val bad = PlanEngine.verify(chosen, after)
                if (bad.isEmpty()) {
                    conn2.exec("touch /tmp/rb/ok")
                    say("تم التحقق: كل الإعدادات المطلوبة مطبّقة، وأُلغي التراجع التلقائي")
                    return ApplyReport(true, "نجحت البرمجة", lines, manual, backupId, host2)
                }
                bad.forEach { say("فشل التحقق: $it") }
                conn2.exec("touch /tmp/rb/ok")
                conn2.exec(CommandBuilder.restoreCommand(pkgs))
                say("جارٍ التراجع إلى النسخة الاحتياطية")
                return ApplyReport(false, "فشل التحقق وتم التراجع", lines, manual + bad, backupId, host2)
            } finally {
                conn2.close()
            }
        } catch (e: Exception) {
            say("خطأ: ${e.message}")
            if (beforeApply && backupId != null) {
                try { withConn(c) { it.exec("touch /tmp/rb/ok") } } catch (ignored: Exception) { }
            }
            return ApplyReport(false, "فشل التطبيق", lines, manual + (e.message ?: "خطأ غير معروف"), backupId, null)
        }
    }

    fun restore(c: Creds, info: DeviceInfo, b: Backup, progress: (String) -> Unit): ApplyReport {
        val lines = ArrayList<String>()
        fun say(s: String) { lines.add(s); progress(s); store.log(s) }
        if (!b.intact)
            return ApplyReport(false, "النسخة تالفة", listOf("فشل التحقق من سلامة النسخة (SHA-256)"), emptyList(), b.id, null)
        if (b.board != info.boardName)
            return ApplyReport(false, "منع الاستعادة", listOf(
                "النسخة لجهاز «${b.board}» والجهاز المتصل «${info.boardName}». لا تُستعاد نسخة كاملة على جهاز مختلف."),
                emptyList(), b.id, null)
        val pkgs = b.packages.keys.filter { it in SUPPORTED_PACKAGES }
        try {
            withConn(c) { conn ->
                for (p in pkgs) {
                    say("استعادة $p")
                    val r = conn.exec("uci import $p", b.packages.getValue(p))
                    check(r.code == 0) { "فشل استيراد $p: ${r.err.trim()}" }
                    check(conn.exec("uci commit $p").code == 0) { "فشل حفظ $p" }
                }
                conn.exec(CommandBuilder.reloadCommand(pkgs.toSet()))
            }
            Thread.sleep(8000)
            val re = reconnect(c, listOf(c.host))
                ?: return ApplyReport(false, "فُقد الاتصال بعد الاستعادة", lines,
                    listOf("قد يكون عنوان الجهاز عاد إلى قيمته القديمة؛ جرّب الاتصال به من جديد"), b.id, null)
            val bad = ArrayList<String>()
            try {
                for (p in pkgs) {
                    val after = re.first.exec("uci -q export $p").out
                    if (UciParser.parse(p, after) != UciParser.parse(p, b.packages.getValue(p))) bad.add(p)
                }
            } finally {
                re.first.close()
            }
            return if (bad.isEmpty()) {
                say("تمت الاستعادة والتحقق منها")
                ApplyReport(true, "تمت الاستعادة", lines, emptyList(), b.id, re.second)
            } else {
                ApplyReport(false, "الاستعادة لم تتطابق تمامًا", lines,
                    bad.map { "$it: لا يطابق النسخة بعد الاستعادة" }, b.id, re.second)
            }
        } catch (e: Exception) {
            say("خطأ: ${e.message}")
            return ApplyReport(false, "فشلت الاستعادة", lines, listOf(e.message ?: "خطأ غير معروف"), b.id, null)
        }
    }
}
