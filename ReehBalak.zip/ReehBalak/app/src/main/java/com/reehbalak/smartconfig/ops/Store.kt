package com.reehbalak.smartconfig.ops

import android.content.Context
import com.reehbalak.smartconfig.core.Backup
import com.reehbalak.smartconfig.core.Template
import com.reehbalak.smartconfig.core.UciSection
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

object Json {
    private fun sec(s: UciSection): JSONObject = JSONObject()
        .put("type", s.type)
        .put("name", s.name ?: JSONObject.NULL)
        .put("anon", s.anonIndex)
        .put("options", JSONObject(s.options))
        .put("lists", JSONObject(s.lists.mapValues { JSONArray(it.value) }))

    private fun sec(o: JSONObject): UciSection {
        val opts = LinkedHashMap<String, String>()
        o.optJSONObject("options")?.let { oo -> for (k in oo.keys()) opts[k] = oo.getString(k) }
        val lists = LinkedHashMap<String, List<String>>()
        o.optJSONObject("lists")?.let { lo ->
            for (k in lo.keys()) {
                val a = lo.getJSONArray(k)
                lists[k] = (0 until a.length()).map { a.getString(it) }
            }
        }
        val name = if (o.isNull("name")) null else o.getString("name")
        return UciSection(o.getString("type"), name, o.optInt("anon", 0), opts, lists)
    }

    fun toJson(t: Template): JSONObject {
        val pk = JSONObject()
        for ((p, list) in t.packages) pk.put(p, JSONArray(list.map { sec(it) }))
        return JSONObject()
            .put("kind", "template").put("format", 1).put("app", "ReehBalak")
            .put("id", t.id).put("name", t.name)
            .put("createdAt", t.createdAt).put("updatedAt", t.updatedAt)
            .put("board", t.board).put("model", t.model)
            .put("distribution", t.distribution).put("version", t.version)
            .put("includesSecrets", t.includesSecrets)
            .put("packages", pk)
    }

    fun template(o: JSONObject): Template {
        val pkgs = LinkedHashMap<String, List<UciSection>>()
        val po = o.getJSONObject("packages")
        for (p in po.keys()) {
            val a = po.getJSONArray(p)
            pkgs[p] = (0 until a.length()).map { sec(a.getJSONObject(it)) }
        }
        return Template(
            id = o.getString("id"), name = o.getString("name"),
            createdAt = o.optLong("createdAt"), updatedAt = o.optLong("updatedAt"),
            board = o.optString("board"), model = o.optString("model"),
            distribution = o.optString("distribution"), version = o.optString("version"),
            includesSecrets = o.optBoolean("includesSecrets"), packages = pkgs,
        )
    }

    fun toJson(b: Backup): JSONObject = JSONObject()
        .put("kind", "backup").put("format", 1).put("app", "ReehBalak")
        .put("id", b.id).put("host", b.host).put("hostname", b.hostname)
        .put("board", b.board).put("model", b.model).put("version", b.version)
        .put("createdAt", b.createdAt).put("sha256", b.sha256)
        .put("packages", JSONObject(b.packages))

    fun backup(o: JSONObject): Backup {
        val pk = LinkedHashMap<String, String>()
        val po = o.getJSONObject("packages")
        for (k in po.keys()) pk[k] = po.getString(k)
        return Backup(
            id = o.getString("id"), host = o.optString("host"), hostname = o.optString("hostname"),
            board = o.optString("board"), model = o.optString("model"), version = o.optString("version"),
            createdAt = o.optLong("createdAt"), packages = pk, sha256 = o.getString("sha256"),
        )
    }
}

class Store(private val ctx: Context) {
    private val tplDir = File(ctx.filesDir, "templates").apply { mkdirs() }
    private val bkDir = File(ctx.filesDir, "backups").apply { mkdirs() }
    private val logFile = File(ctx.filesDir, "log.txt")
    private val prefs = ctx.getSharedPreferences("settings", Context.MODE_PRIVATE)
    private val stamp = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US)

    var autoMode: Boolean
        get() = prefs.getBoolean("auto_mode", false)
        set(v) { prefs.edit().putBoolean("auto_mode", v).apply() }

    fun templates(): List<Template> =
        (tplDir.listFiles() ?: emptyArray())
            .mapNotNull { f -> try { Json.template(JSONObject(f.readText())) } catch (e: Exception) { null } }
            .sortedByDescending { it.updatedAt }

    fun saveTemplate(t: Template) = File(tplDir, "${t.id}.json").writeText(Json.toJson(t).toString())
    fun deleteTemplate(id: String) { File(tplDir, "$id.json").delete() }

    fun backups(): List<Backup> =
        (bkDir.listFiles() ?: emptyArray())
            .mapNotNull { f -> try { Json.backup(JSONObject(f.readText())) } catch (e: Exception) { null } }
            .sortedByDescending { it.createdAt }

    fun saveBackup(b: Backup) = File(bkDir, "${b.id}.json").writeText(Json.toJson(b).toString())
    fun deleteBackup(id: String) { File(bkDir, "$id.json").delete() }

    /** السجل لا يحتوي كلمات مرور أو أسرارًا أبدًا: يُمرَّر إليه نص الحالة فقط. */
    fun log(line: String) {
        try { logFile.appendText("${stamp.format(Date())}  $line\n") } catch (e: Exception) { }
    }
    fun readLog(): List<String> =
        if (logFile.exists()) logFile.readLines().takeLast(300).reversed() else emptyList()
    fun clearLog() { logFile.delete() }
}
