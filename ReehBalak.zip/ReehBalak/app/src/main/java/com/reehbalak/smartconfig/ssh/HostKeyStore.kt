package com.reehbalak.smartconfig.ssh

import android.content.Context

/** يحفظ بصمات مفاتيح SSH التي وثق بها المستخدم (ليست أسرارًا). */
class HostKeyStore(context: Context) {
    private val prefs = context.getSharedPreferences("host_keys", Context.MODE_PRIVATE)
    fun get(host: String, port: Int): String? = prefs.getString("$host:$port", null)
    fun put(host: String, port: Int, fingerprint: String) =
        prefs.edit().putString("$host:$port", fingerprint).apply()
    fun remove(host: String, port: Int) = prefs.edit().remove("$host:$port").apply()
}
