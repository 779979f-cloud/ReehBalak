package com.reehbalak.smartconfig.ssh

import com.jcraft.jsch.ChannelExec
import com.jcraft.jsch.HostKey
import com.jcraft.jsch.HostKeyRepository
import com.jcraft.jsch.JSch
import com.jcraft.jsch.JSchException
import com.jcraft.jsch.Session
import com.jcraft.jsch.UserInfo
import org.json.JSONObject
import java.io.ByteArrayInputStream
import java.io.ByteArrayOutputStream
import java.security.MessageDigest
import java.util.Base64

data class Creds(val host: String, val port: Int, val user: String, val pass: String)

data class HostKeyInfo(val type: String, val fingerprint: String)

data class DeviceInfo(
    val hostname: String,
    val model: String,
    val boardName: String,
    val distribution: String,
    val version: String,
    val revision: String,
    val target: String,
    val kernel: String,
    val uid: Int?,
    val hasUci: Boolean,
) {
    val isRoot: Boolean get() = uid == 0
}

data class ExecResult(val out: String, val err: String, val code: Int)

class SshConn(private val session: Session) {
    fun exec(cmd: String, stdin: String? = null, timeoutMs: Long = 30_000): ExecResult {
        val ch = session.openChannel("exec") as ChannelExec
        val out = ByteArrayOutputStream()
        val err = ByteArrayOutputStream()
        ch.setCommand(cmd)
        ch.setOutputStream(out)
        ch.setErrStream(err)
        if (stdin != null) ch.setInputStream(ByteArrayInputStream(stdin.toByteArray(Charsets.UTF_8)))
        ch.connect(10_000)
        val end = System.currentTimeMillis() + timeoutMs
        while (!ch.isClosed && System.currentTimeMillis() < end) Thread.sleep(40)
        val code = if (ch.isClosed) ch.exitStatus else -1
        ch.disconnect()
        return ExecResult(out.toString("UTF-8"), err.toString("UTF-8"), code)
    }

    fun close() = session.disconnect()
}

sealed class Open {
    class Ok(val conn: SshConn) : Open()
    class UnknownKey(val key: HostKeyInfo) : Open()
    class KeyChanged(val expected: String, val actual: String) : Open()
    class Failure(val message: String) : Open()
}

sealed class ConnectResult {
    data class Success(val info: DeviceInfo) : ConnectResult()
    data class UnknownKey(val key: HostKeyInfo) : ConnectResult()
    data class KeyChanged(val expected: String, val actual: String) : ConnectResult()
    data class Failure(val message: String) : ConnectResult()
}

class SshService(private val store: HostKeyStore) {

    fun trust(host: String, port: Int, fingerprint: String) = store.put(host, port, fingerprint)
    fun knownFingerprint(host: String, port: Int): String? = store.get(host, port)

    fun open(host: String, port: Int, user: String, password: String): Open {
        val stored = store.get(host, port)
        var captured: HostKeyInfo? = null
        var status = -1

        val repo = object : HostKeyRepository {
            override fun check(h: String?, key: ByteArray): Int {
                val info = describe(key)
                captured = info
                status = when {
                    stored == null -> HostKeyRepository.NOT_INCLUDED
                    stored == info.fingerprint -> HostKeyRepository.OK
                    else -> HostKeyRepository.CHANGED
                }
                return status
            }
            override fun add(hostKey: HostKey?, ui: UserInfo?) {}
            override fun remove(h: String?, type: String?) {}
            override fun remove(h: String?, type: String?, key: ByteArray?) {}
            override fun getKnownHostsRepositoryID(): String = "reehbalak"
            override fun getHostKey(): Array<HostKey> = emptyArray()
            override fun getHostKey(h: String?, type: String?): Array<HostKey> = emptyArray()
        }

        val session = JSch().getSession(user, host, port)
        session.setPassword(password)
        session.setHostKeyRepository(repo)
        session.setConfig("StrictHostKeyChecking", "yes")
        session.setConfig("PreferredAuthentications", "password,keyboard-interactive")
        try {
            session.connect(10_000)
            return Open.Ok(SshConn(session))
        } catch (e: JSchException) {
            session.disconnect()
            val cap = captured
            val msg = e.message ?: ""
            return when {
                status == HostKeyRepository.CHANGED && cap != null -> Open.KeyChanged(stored ?: "", cap.fingerprint)
                status == HostKeyRepository.NOT_INCLUDED && cap != null -> Open.UnknownKey(cap)
                msg.contains("Auth fail", true) -> Open.Failure("اسم المستخدم أو كلمة المرور غير صحيحة")
                msg.contains("timeout", true) || msg.contains("timed out", true) ->
                    Open.Failure("انتهت مهلة الاتصال. تحقق من العنوان والشبكة")
                msg.contains("refused", true) -> Open.Failure("رفض الجهاز الاتصال. تحقق من المنفذ وتفعيل SSH")
                else -> Open.Failure("تعذر الاتصال: $msg")
            }
        } catch (e: Exception) {
            session.disconnect()
            return Open.Failure("خطأ غير متوقع: ${e.message}")
        }
    }

    fun readInfo(conn: SshConn): DeviceInfo? {
        val board = conn.exec("ubus call system board 2>/dev/null").out
        if (board.isBlank()) return null
        val json = try { JSONObject(board) } catch (e: Exception) { return null }
        val rel = json.optJSONObject("release")
        val uid = conn.exec("id -u").out.trim().toIntOrNull()
        val hasUci = conn.exec("command -v uci").out.isNotBlank()
        return DeviceInfo(
            hostname = json.optString("hostname"),
            model = json.optString("model"),
            boardName = json.optString("board_name"),
            distribution = rel?.optString("distribution") ?: "",
            version = rel?.optString("version") ?: "",
            revision = rel?.optString("revision") ?: "",
            target = rel?.optString("target") ?: "",
            kernel = json.optString("kernel"),
            uid = uid,
            hasUci = hasUci,
        )
    }

    fun probe(host: String, port: Int, user: String, password: String): ConnectResult =
        when (val o = open(host, port, user, password)) {
            is Open.Ok -> try {
                val i = readInfo(o.conn)
                if (i == null) ConnectResult.Failure("الاتصال نجح لكن الجهاز لا يبدو OpenWrt (الأمر ubus غير متوفر)")
                else ConnectResult.Success(i)
            } finally {
                o.conn.close()
            }
            is Open.UnknownKey -> ConnectResult.UnknownKey(o.key)
            is Open.KeyChanged -> ConnectResult.KeyChanged(o.expected, o.actual)
            is Open.Failure -> ConnectResult.Failure(o.message)
        }

    companion object {
        fun describe(key: ByteArray): HostKeyInfo {
            val digest = MessageDigest.getInstance("SHA-256").digest(key)
            val fp = "SHA256:" + Base64.getEncoder().withoutPadding().encodeToString(digest)
            val type = try { HostKey("x", key).type } catch (e: Exception) { "unknown" }
            return HostKeyInfo(type, fp)
        }
    }
}
