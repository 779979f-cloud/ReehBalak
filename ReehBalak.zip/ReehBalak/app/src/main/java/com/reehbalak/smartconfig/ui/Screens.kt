package com.reehbalak.smartconfig.ui

import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CenterAlignedTopAppBar
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.reehbalak.smartconfig.MainViewModel
import com.reehbalak.smartconfig.Screen
import com.reehbalak.smartconfig.core.Backup
import com.reehbalak.smartconfig.core.Compat
import com.reehbalak.smartconfig.core.GROUP_TITLES
import com.reehbalak.smartconfig.core.Level
import com.reehbalak.smartconfig.core.Sanitizer
import com.reehbalak.smartconfig.core.Template
import com.reehbalak.smartconfig.editorSource
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private val dateFmt = SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.US)
private fun fmt(t: Long) = dateFmt.format(Date(t))
private fun title(s: Screen) = when (s) {
    Screen.Home -> "ريح بالك"
    Screen.Discover -> "البحث عن الأجهزة"
    Screen.Connect -> "إضافة جهاز والاتصال به"
    Screen.Info -> "معلومات الجهاز"
    Screen.ReadSettings -> "قراءة الإعدادات"
    Screen.Select -> "إنشاء قالب"
    Screen.Templates -> "قوالب البرمجة"
    Screen.Auto -> "البرمجة التلقائية"
    Screen.Preview -> "معاينة التغييرات"
    Screen.Result -> "تقرير التنفيذ"
    Screen.Backups -> "النسخ الاحتياطي والاستعادة"
    Screen.Log -> "سجل العمليات والأخطاء"
    Screen.AppSettings -> "إعدادات التطبيق"
}

// ---------- مساعدات ----------
@Composable
private fun Page(content: @Composable ColumnScope.() -> Unit) {
    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp),
        content = content,
    )
}

@Composable
private fun Btn(text: String, enabled: Boolean = true, onClick: () -> Unit) {
    Button(onClick = onClick, enabled = enabled, modifier = Modifier.fillMaxWidth()) { Text(text) }
}

@Composable
private fun Bold(text: String) { Text(text, fontWeight = FontWeight.Bold) }

@Composable
private fun Check(label: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth().clickable { onChange(!checked) }, verticalAlignment = Alignment.CenterVertically) {
        Checkbox(checked, { onChange(it) })
        Text(label, Modifier.weight(1f))
    }
}

@Composable
private fun Banner(text: String, isError: Boolean, onClose: () -> Unit) {
    Card(Modifier.fillMaxWidth().padding(8.dp)) {
        Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
            Text(text, Modifier.weight(1f),
                color = if (isError) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.primary)
            TextButton(onClick = onClose) { Text("إغلاق") }
        }
    }
}

@Composable
private fun Busy(msg: String) {
    Box(Modifier.fillMaxSize().background(Color(0x99000000)).clickable(enabled = true, onClick = {}),
        contentAlignment = Alignment.Center) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            CircularProgressIndicator(color = Color.White)
            Spacer(Modifier.height(12.dp))
            Text(msg, color = Color.White)
        }
    }
}

@Composable
private fun Row2(label: String, value: String) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
        Bold(label)
        Text(value.ifBlank { "—" }, fontFamily = FontFamily.Monospace)
    }
}

private fun mask(option: String, v: String?): String =
    if (v == null) "—" else if (option in Sanitizer.SECRET_OPTIONS) "••••" else v

// ---------- التطبيق ----------
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun App(vm: MainViewModel) {
    val s = vm.state
    BackHandler(enabled = s.screen != Screen.Home) { vm.back() }

    Box(Modifier.fillMaxSize()) {
        Scaffold(topBar = { CenterAlignedTopAppBar(title = { Text(title(s.screen)) }) }) { pad ->
            Column(Modifier.padding(pad).fillMaxSize()) {
                s.error?.let { Banner(it, true) { vm.clearMsg() } }
                s.message?.let { Banner(it, false) { vm.clearMsg() } }
                Box(Modifier.weight(1f)) {
                    when (s.screen) {
                        Screen.Home -> HomeScreen(vm)
                        Screen.Discover -> DiscoverScreen(vm)
                        Screen.Connect -> ConnectScreen(vm)
                        Screen.Info -> InfoScreen(vm)
                        Screen.ReadSettings -> ReadScreen(vm)
                        Screen.Select -> EditorScreen(vm)
                        Screen.Templates -> TemplatesScreen(vm)
                        Screen.Auto -> AutoScreen(vm)
                        Screen.Preview -> PreviewScreen(vm)
                        Screen.Result -> ResultScreen(vm)
                        Screen.Backups -> BackupsScreen(vm)
                        Screen.Log -> LogScreen(vm)
                        Screen.AppSettings -> SettingsScreen(vm)
                    }
                }
            }
        }
        if (s.busy) Busy(s.busyMsg)
    }

    s.unknownKey?.let { k ->
        AlertDialog(
            onDismissRequest = vm::dismissDialog,
            title = { Text("جهاز جديد: تأكيد البصمة") },
            text = {
                Text("نوع المفتاح: ${k.type}\n\nالبصمة:\n${k.fingerprint}\n\n" +
                    "تأكد أنها تطابق بصمة الراوتر، ثم اضغط «وثوق». لن تُرسل كلمة المرور قبل ذلك.")
            },
            confirmButton = { TextButton(onClick = vm::trustAndRetry) { Text("وثوق ومتابعة") } },
            dismissButton = { TextButton(onClick = vm::dismissDialog) { Text("إلغاء") } },
        )
    }
    s.keyChanged?.let { (old, new) ->
        AlertDialog(
            onDismissRequest = vm::dismissDialog,
            title = { Text("تحذير: تغيّرت بصمة الجهاز") },
            text = {
                Text("قد يكون الجهاز أعيد ضبطه، وقد يكون هناك من ينتحل شخصيته على الشبكة.\n\n" +
                    "المحفوظة:\n$old\n\nالحالية:\n$new")
            },
            confirmButton = { TextButton(onClick = vm::replaceKeyAndRetry) { Text("أعرف السبب، استبدل") } },
            dismissButton = { TextButton(onClick = vm::dismissDialog) { Text("إلغاء (الأفضل)") } },
        )
    }
}

// ---------- الرئيسية ----------
@Composable
fun HomeScreen(vm: MainViewModel) {
    val s = vm.state
    Page {
        Text("برمج مودمًا واحدًا، ثم كرّر بضغطة.", style = MaterialTheme.typography.titleMedium)
        if (s.info != null) {
            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Bold("الجهاز المتصل: ${s.info.hostname.ifBlank { s.info.model }}")
                    Text("${s.connectedHost}")
                    Btn("متابعة العمل على الجهاز") { vm.go(Screen.Info) }
                }
            }
        }
        Btn("البحث عن الأجهزة في الشبكة") { vm.go(Screen.Discover) }
        Btn("إضافة جهاز والاتصال به (OpenWrt)") { vm.go(Screen.Connect) }
        Btn("قوالب البرمجة") { vm.go(Screen.Templates) }
        Btn("النسخ الاحتياطي والاستعادة") { vm.go(Screen.Backups) }
        Btn("سجل العمليات والأخطاء") { vm.go(Screen.Log) }
        Btn("إعدادات التطبيق") { vm.go(Screen.AppSettings) }
    }
}

// ---------- اكتشاف ----------
@Composable
fun DiscoverScreen(vm: MainViewModel) {
    val s = vm.state
    Page {
        Text("يفحص هذا الخيار شبكة Wi-Fi التي أنت متصل بها (المنفذ 22 فقط) ولا يحاول الدخول لأي جهاز.")
        Btn("ابدأ الفحص") { vm.scan() }
        if (s.scanned && s.found.isEmpty()) Text("لم يُعثر على أجهزة SSH.")
        s.found.forEach { f ->
            Card(Modifier.fillMaxWidth()) {
                Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Bold(f.ip)
                        Text(f.banner.ifBlank { "SSH" }, fontFamily = FontFamily.Monospace, fontSize = 12.sp)
                    }
                    Button(onClick = { vm.pick(f.ip) }) { Text("اتصال") }
                }
            }
        }
    }
}

// ---------- اتصال ----------
@Composable
fun ConnectScreen(vm: MainViewModel) {
    val s = vm.state
    var host by rememberSaveable(s.prefillHost) { mutableStateOf(s.prefillHost) }
    var port by rememberSaveable { mutableStateOf("22") }
    var user by rememberSaveable { mutableStateOf("root") }
    var pass by remember { mutableStateOf("") }
    Page {
        OutlinedTextField(host, { host = it }, label = { Text("عنوان IP") }, singleLine = true,
            modifier = Modifier.fillMaxWidth(), keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Uri))
        OutlinedTextField(port, { port = it }, label = { Text("منفذ SSH") }, singleLine = true,
            modifier = Modifier.fillMaxWidth(), keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number))
        OutlinedTextField(user, { user = it }, label = { Text("اسم المستخدم") }, singleLine = true,
            modifier = Modifier.fillMaxWidth())
        OutlinedTextField(pass, { pass = it }, label = { Text("كلمة المرور") }, singleLine = true,
            modifier = Modifier.fillMaxWidth(), visualTransformation = PasswordVisualTransformation(),
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password))
        Btn("اتصال وفحص الجهاز", enabled = !s.busy) { vm.connect(host, port, user, pass) }
        Text("كلمة المرور تبقى في الذاكرة طوال الجلسة فقط ولا تُحفظ على الهاتف.",
            style = MaterialTheme.typography.bodySmall)
    }
}

// ---------- معلومات الجهاز ----------
@Composable
fun InfoScreen(vm: MainViewModel) {
    val i = vm.state.info ?: return
    Page {
        Row2("اسم الجهاز", i.hostname)
        Row2("الطراز", i.model)
        Row2("اللوحة", i.boardName)
        Row2("النظام", "${i.distribution} ${i.version}")
        Row2("المعمارية", i.target)
        Row2("النواة", i.kernel)
        Row2("الصلاحية", if (i.isRoot) "root (كاملة)" else "مستخدم محدود (uid=${i.uid})")
        Row2("أداة uci", if (i.hasUci) "متوفرة" else "غير متوفرة")
        if (!i.isRoot || !i.hasUci)
            Text("لا يمكن التعديل: يلزم حساب root وأداة uci.", color = MaterialTheme.colorScheme.error)
        val ok = i.isRoot && i.hasUci
        Btn("قراءة الإعدادات وإنشاء قالب", ok) { vm.readSettings() }
        Btn("برمجة تلقائية بقالب محفوظ", ok) { vm.openAuto() }
        Btn("أخذ نسخة احتياطية الآن", ok) { vm.backupNow() }
        Btn("قطع الاتصال") { vm.disconnect() }
    }
}

// ---------- قراءة الإعدادات ----------
@Composable
fun ReadScreen(vm: MainViewModel) {
    val snap = vm.state.snapshot ?: return
    Page {
        snap.forEach { (pkg, pk) ->
            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(12.dp)) {
                    Bold(GROUP_TITLES[pkg] ?: pkg)
                    Text("${pk.sections.size} قسمًا")
                }
            }
        }
        Text("غير مدعوم بعد: قراءة الحزم المثبتة (opkg) وإعدادات أخرى خارج الحزم أعلاه.",
            style = MaterialTheme.typography.bodySmall)
        Btn("إنشاء قالب من هذه الإعدادات") { vm.startCreate() }
    }
}

// ---------- إنشاء/تعديل قالب ----------
@Composable
fun EditorScreen(vm: MainViewModel) {
    val e = vm.state.editor ?: return
    val (src, notes) = editorSource(e)
    LazyColumn(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
        item {
            OutlinedTextField(e.name, { vm.setEditorName(it) }, label = { Text("اسم القالب") },
                singleLine = true, modifier = Modifier.fillMaxWidth())
        }
        if (e.base == null) {
            item {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Switch(e.includeSecrets, { vm.setEditorSecrets(it) })
                    Text("  تضمين كلمات المرور (Wi-Fi وPPPoE)", Modifier.weight(1f))
                }
            }
        }
        if (notes.isNotEmpty()) {
            item {
                Text("استُبعد تلقائيًا حفاظًا على الأمان وخصوصية الجهاز:\n" + notes.joinToString("\n") { "• $it" },
                    style = MaterialTheme.typography.bodySmall)
            }
        }
        src.forEach { (pkg, secs) ->
            item(key = "h$pkg") {
                Check(GROUP_TITLES[pkg] ?: pkg,
                    secs.all { "$pkg|${it.key}" in e.selected }) { on -> vm.toggleAll(pkg, secs.map { it.key }, on) }
            }
            items(secs, key = { "$pkg|${it.key}" }) { sec ->
                Row(Modifier.padding(start = 24.dp)) {
                    Check("${sec.label} — ${sec.options.size + sec.lists.size} خيار", "$pkg|${sec.key}" in e.selected) {
                        vm.toggleSection("$pkg|${sec.key}")
                    }
                }
            }
        }
        item { Btn("حفظ القالب") { vm.saveEditor() } }
    }
}

// ---------- القوالب ----------
@Composable
fun TemplatesScreen(vm: MainViewModel) {
    val s = vm.state
    var del by remember { mutableStateOf<Template?>(null) }
    val exportL = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/json")) { uri ->
        if (uri != null) vm.exportTo(uri)
    }
    val importL = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) vm.importFile(uri)
    }
    Page {
        Btn("استيراد قالب أو نسخة احتياطية من ملف") { importL.launch(arrayOf("*/*")) }
        if (s.templates.isEmpty())
            Text("لا توجد قوالب بعد. اتصل بجهاز، اقرأ إعداداته، ثم أنشئ قالبًا.")
        s.templates.forEach { t ->
            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Bold(t.name)
                    Text("الجهاز: ${t.model.ifBlank { t.board }} — ${t.distribution} ${t.version}")
                    Text("أُنشئ: ${fmt(t.createdAt)} | عُدّل: ${fmt(t.updatedAt)}", fontSize = 12.sp)
                    Text("الأقسام: ${t.packages.values.sumOf { it.size }}" +
                        if (t.includesSecrets) " | يتضمن كلمات مرور" else "", fontSize = 12.sp)
                    Row {
                        TextButton(onClick = { vm.editTemplate(t) }) { Text("تعديل") }
                        TextButton(onClick = { vm.duplicateTemplate(t) }) { Text("نسخ") }
                        TextButton(onClick = { exportL.launch(vm.exportTemplate(t)) }) { Text("تصدير") }
                        TextButton(onClick = { del = t }) { Text("حذف") }
                    }
                }
            }
        }
    }
    del?.let { t ->
        AlertDialog(
            onDismissRequest = { del = null },
            title = { Text("حذف القالب؟") },
            text = { Text(t.name) },
            confirmButton = { TextButton(onClick = { vm.deleteTemplate(t); del = null }) { Text("حذف") } },
            dismissButton = { TextButton(onClick = { del = null }) { Text("إلغاء") } },
        )
    }
}

// ---------- البرمجة التلقائية ----------
@Composable
fun AutoScreen(vm: MainViewModel) {
    val s = vm.state
    val info = s.info ?: return
    Page {
        Text("اختر القالب لتطبيقه على: ${info.hostname.ifBlank { info.model }}")
        if (s.autoMode) Text("وضع التشغيل التلقائي مفعّل: القالب المتوافق تمامًا يُطبَّق دون معاينة.",
            style = MaterialTheme.typography.bodySmall)
        if (s.templates.isEmpty()) Text("لا توجد قوالب محفوظة.")
        s.templates.forEach { t ->
            val c = Compat.check(t, info)
            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Bold(t.name)
                    c.notes.forEach {
                        Text("• $it", fontSize = 12.sp,
                            color = if (c.level == Level.OK) MaterialTheme.colorScheme.primary
                            else MaterialTheme.colorScheme.error)
                    }
                    Btn("مقارنة ومعاينة", c.level != Level.BLOCK) { vm.chooseTemplate(t) }
                }
            }
        }
    }
}

// ---------- معاينة ----------
@Composable
fun PreviewScreen(vm: MainViewModel) {
    val ps = vm.state.planState ?: return
    val plan = ps.plan
    val needCut = plan.warnings.isNotEmpty()
    val canApply = ps.compat.level != Level.BLOCK &&
        plan.sections.any { it.pkg in ps.selectedPkgs } &&
        (!needCut || ps.confirmCut) &&
        (ps.compat.level != Level.WARN || ps.confirmBoard)
    Page {
        Bold("القالب: ${ps.template.name}")
        ps.compat.notes.forEach {
            Text("• $it", color = if (ps.compat.level == Level.OK) MaterialTheme.colorScheme.primary
            else MaterialTheme.colorScheme.error)
        }
        if (plan.sections.isEmpty()) Text("الجهاز مطابق للقالب، لا توجد تغييرات.")
        plan.sections.groupBy { it.pkg }.forEach { (pkg, secs) ->
            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Check(GROUP_TITLES[pkg] ?: pkg, pkg in ps.selectedPkgs) { vm.togglePkg(pkg) }
                    secs.take(30).forEach { sec ->
                        Bold((if (sec.isNew) "＋ جديد: " else "") + sec.section.label)
                        sec.changes.take(12).forEach { c ->
                            Text("${c.option}: ${mask(c.option, c.oldValue)} ← ${mask(c.option, c.newValue)}",
                                fontFamily = FontFamily.Monospace, fontSize = 12.sp)
                        }
                    }
                    if (secs.size > 30) Text("… و${secs.size - 30} أقسام أخرى")
                }
            }
        }
        if (plan.conflicts.isNotEmpty()) {
            Bold("تحتاج تدخلًا يدويًا (لن تُطبَّق):")
            plan.conflicts.forEach { Text("• ${it.pkg}: ${it.label} — ${it.reason}", fontSize = 12.sp) }
        }
        if (needCut) {
            plan.warnings.forEach { Text("⚠ $it", color = MaterialTheme.colorScheme.error) }
            Check("أفهم أن الاتصال قد ينقطع (سيتراجع الجهاز تلقائيًا إن لم يتأكد النجاح)", ps.confirmCut) {
                vm.setConfirmCut(it)
            }
        }
        if (ps.compat.level == Level.WARN)
            Check("أؤكد التطبيق رغم اختلاف الجهاز عن القالب", ps.confirmBoard) { vm.setConfirmBoard(it) }
        Btn("تطبيق الإعدادات المحددة", canApply) { vm.applyPlan() }
    }
}

// ---------- التقرير ----------
@Composable
fun ResultScreen(vm: MainViewModel) {
    val r = vm.state.report ?: return
    Page {
        Text(r.title, style = MaterialTheme.typography.titleLarge,
            color = if (r.ok) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.error)
        r.lines.forEach { Text("• $it", fontSize = 13.sp) }
        if (r.manual.isNotEmpty()) {
            Bold("تحتاج تدخلًا يدويًا:")
            r.manual.forEach { Text("• $it", fontSize = 13.sp) }
        }
        if (r.backupId != null) Text("نسخة احتياطية محفوظة (متاحة من شاشة النسخ الاحتياطي).", fontSize = 12.sp)
        Btn("رجوع") { vm.back() }
        Btn("النسخ الاحتياطي والاستعادة") { vm.go(Screen.Backups) }
    }
}

// ---------- النسخ الاحتياطي ----------
@Composable
fun BackupsScreen(vm: MainViewModel) {
    val s = vm.state
    var restoreTarget by remember { mutableStateOf<Backup?>(null) }
    val exportL = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/json")) { uri ->
        if (uri != null) vm.exportTo(uri)
    }
    val importL = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) vm.importFile(uri)
    }
    Page {
        Btn("نسخة احتياطية للجهاز المتصل الآن", s.info != null) { vm.backupNow() }
        Btn("استيراد من ملف") { importL.launch(arrayOf("*/*")) }
        if (s.info == null) Text("للاستعادة اتصل بالجهاز أولًا.", style = MaterialTheme.typography.bodySmall)
        if (s.backups.isEmpty()) Text("لا توجد نسخ احتياطية.")
        s.backups.forEach { b ->
            val same = s.info != null && s.info.boardName == b.board
            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Bold("${b.hostname.ifBlank { b.model }} — ${fmt(b.createdAt)}")
                    Text("اللوحة: ${b.board} | الإصدار: ${b.version}", fontSize = 12.sp)
                    Text("الحزم: ${b.packages.keys.joinToString("، ")}", fontSize = 12.sp)
                    if (!b.intact) Text("⚠ فشل التحقق من سلامة النسخة", color = MaterialTheme.colorScheme.error)
                    if (s.info != null && !same)
                        Text("لا تُستعاد على الجهاز المتصل: لوحة مختلفة", fontSize = 12.sp,
                            color = MaterialTheme.colorScheme.error)
                    Row {
                        TextButton(onClick = { restoreTarget = b }, enabled = same && b.intact) { Text("استعادة") }
                        TextButton(onClick = { exportL.launch(vm.exportBackup(b)) }) { Text("تصدير") }
                        TextButton(onClick = { vm.deleteBackup(b) }) { Text("حذف") }
                    }
                }
            }
        }
    }
    restoreTarget?.let { b ->
        AlertDialog(
            onDismissRequest = { restoreTarget = null },
            title = { Text("استعادة النسخة؟") },
            text = { Text("سيُستبدل إعدادات: ${b.packages.keys.joinToString("، ")} ، وقد ينقطع الاتصال لحظات.") },
            confirmButton = { TextButton(onClick = { vm.restore(b); restoreTarget = null }) { Text("استعادة") } },
            dismissButton = { TextButton(onClick = { restoreTarget = null }) { Text("إلغاء") } },
        )
    }
}

// ---------- السجل ----------
@Composable
fun LogScreen(vm: MainViewModel) {
    Page {
        Btn("مسح السجل") { vm.clearLog() }
        if (vm.state.log.isEmpty()) Text("السجل فارغ.")
        vm.state.log.forEach { Text(it, fontFamily = FontFamily.Monospace, fontSize = 11.sp) }
        Text("السجل لا يحتوي كلمات مرور ولا مفاتيح.", style = MaterialTheme.typography.bodySmall)
    }
}

// ---------- إعدادات التطبيق ----------
@Composable
fun SettingsScreen(vm: MainViewModel) {
    val s = vm.state
    Page {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Switch(s.autoMode, { vm.setAutoMode(it) })
            Column(Modifier.weight(1f).padding(start = 12.dp)) {
                Bold("وضع التشغيل التلقائي")
                Text("يطبّق القالب دون معاينة فقط إذا كان الجهاز متوافقًا تمامًا (نفس اللوحة والإصدار) " +
                    "ولا توجد تعارضات. النسخ الاحتياطي والتحقق والتراجع التلقائي تعمل دائمًا.",
                    style = MaterialTheme.typography.bodySmall)
            }
        }
        Text("ريح بالك 0.2.0 — يدعم OpenWrt عبر SSH.", style = MaterialTheme.typography.bodySmall)
    }
}
