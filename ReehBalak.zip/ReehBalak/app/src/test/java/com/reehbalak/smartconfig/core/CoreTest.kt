package com.reehbalak.smartconfig.core

import com.reehbalak.smartconfig.ssh.DeviceInfo
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

private val SAMPLE = """
package network

config interface 'lan'
	option device 'br-lan'
	option proto 'static'
	list ipaddr '192.168.1.1/24'
	option note 'it'\''s'

config route
	option target '10.0.0.0/8'

config route
	option target '172.16.0.0/12'

config interface 'wg0'
	option proto 'wireguard'
	option private_key 'SECRET'
""".trimIndent()

private fun sec(type: String, name: String?, vararg o: Pair<String, String>, idx: Int = 0) =
    UciSection(type, name, idx, o.toMap(), emptyMap())

class CoreTest {

    @Test fun parserHandlesQuotesListsAndAnonymous() {
        val p = UciParser.parse("network", SAMPLE)
        assertEquals(5, p.sections.size)
        val lan = p.sections[0]
        assertEquals("lan", lan.name)
        assertEquals("it's", lan.options["note"])
        assertEquals(listOf("192.168.1.1/24"), lan.lists["ipaddr"])
        assertEquals("@route#0", p.sections[1].key)
        assertEquals("@route#1", p.sections[2].key)
    }

    @Test fun sanitizerDropsHardwareAndSecrets() {
        val wifi = UciSection("wifi-iface", "w", 0, mapOf("ssid" to "A", "key" to "pw", "macaddr" to "aa"), emptyMap())
        val r = Sanitizer.clean("wireless", listOf(wifi), includeSecrets = false)
        assertEquals(mapOf("ssid" to "A"), r.sections[0].options)
        val r2 = Sanitizer.clean("wireless", listOf(wifi), includeSecrets = true)
        assertEquals(mapOf("ssid" to "A", "key" to "pw"), r2.sections[0].options)
    }

    @Test fun sanitizerDropsWireguardAndNetworkHardware() {
        val p = UciParser.parse("network", SAMPLE)
        val r = Sanitizer.clean("network", p.sections, false)
        assertFalse(r.sections.any { it.options.containsKey("private_key") })
        assertFalse(r.sections.any { it.options.containsKey("device") })
        val dev = sec("device", "br-lan", "name" to "br-lan")
        assertTrue(Sanitizer.clean("network", listOf(dev), false).sections.isEmpty())
    }

    @Test fun planDetectsChangesNewSectionsAndSkipsUnchanged() {
        val dev = mapOf("network" to UciPackage("network", listOf(
            sec("interface", "lan", "proto" to "static", "netmask" to "255.255.255.0"))))
        val tpl = mapOf("network" to listOf(
            sec("interface", "lan", "proto" to "static", "netmask" to "255.255.0.0"),
            sec("interface", "guest", "proto" to "static")))
        val plan = PlanEngine.build(tpl, dev)
        assertEquals(2, plan.sections.size)
        assertEquals("network.lan", plan.sections[0].targetAddr)
        assertEquals(1, plan.sections[0].changes.size)
        assertTrue(plan.sections[1].isNew)
        assertTrue(plan.warnings.isNotEmpty())
    }

    @Test fun planIsEmptyWhenDeviceMatches() {
        val s = sec("interface", "lan", "proto" to "static")
        val plan = PlanEngine.build(mapOf("network" to listOf(s)), mapOf("network" to UciPackage("network", listOf(s))))
        assertTrue(plan.sections.isEmpty())
    }

    @Test fun wirelessMissingRadioIsConflict() {
        val dev = mapOf("wireless" to UciPackage("wireless", listOf(sec("wifi-device", "radio0", "band" to "2g"))))
        val tpl = mapOf("wireless" to listOf(
            sec("wifi-device", "radio1", "band" to "5g"),
            sec("wifi-iface", "w5", "device" to "radio1", "ssid" to "X"),
            sec("wifi-iface", "w2", "device" to "radio0", "ssid" to "Y")))
        val plan = PlanEngine.build(tpl, dev)
        assertEquals(2, plan.conflicts.size)
        assertEquals(1, plan.sections.size)
        assertEquals("w2", plan.sections[0].section.name)
    }

    @Test fun radioBandMismatchSkipsRadioAndItsIfaces() {
        val dev = mapOf("wireless" to UciPackage("wireless", listOf(sec("wifi-device", "radio0", "band" to "2g"))))
        val tpl = mapOf("wireless" to listOf(
            sec("wifi-device", "radio0", "band" to "5g"),
            sec("wifi-iface", "w", "device" to "radio0", "ssid" to "Y")))
        val plan = PlanEngine.build(tpl, dev)
        assertTrue(plan.sections.isEmpty())
        assertEquals(2, plan.conflicts.size)
    }

    @Test fun unsupportedPackageAndBadIdentifiersAreRejected() {
        val bad = sec("interface", "x; reboot", "proto" to "static")
        val plan = PlanEngine.build(
            mapOf("rpcd" to listOf(bad), "network" to listOf(bad)),
            mapOf("network" to UciPackage("network", emptyList())))
        assertTrue(plan.sections.isEmpty())
        assertEquals(2, plan.conflicts.size)
    }

    @Test fun scriptQuotesValuesAndCommits() {
        val s = sec("interface", "lan", "note" to "a'b; reboot")
        val plan = PlanEngine.build(mapOf("network" to listOf(s)),
            mapOf("network" to UciPackage("network", listOf(sec("interface", "lan")))))
        val script = CommandBuilder.applyScript(plan.sections)
        assertTrue(script.contains("uci set network.lan.note='a'\\''b; reboot'"))
        assertTrue(script.trimEnd().endsWith("uci commit network"))
    }

    @Test fun listsAreReplaced() {
        val tplS = UciSection("interface", "lan", 0, emptyMap(), mapOf("dns" to listOf("1.1.1.1", "8.8.8.8")))
        val devS = UciSection("interface", "lan", 0, emptyMap(), mapOf("dns" to listOf("9.9.9.9")))
        val plan = PlanEngine.build(mapOf("network" to listOf(tplS)), mapOf("network" to UciPackage("network", listOf(devS))))
        val script = CommandBuilder.applyScript(plan.sections)
        assertTrue(script.contains("uci -q delete network.lan.dns"))
        assertTrue(script.contains("uci add_list network.lan.dns='8.8.8.8'"))
    }

    @Test fun verifyDetectsMismatch() {
        val s = sec("interface", "lan", "proto" to "dhcp")
        val plan = PlanEngine.build(mapOf("network" to listOf(s)), mapOf("network" to UciPackage("network", listOf(sec("interface", "lan", "proto" to "static")))))
        assertTrue(PlanEngine.verify(plan.sections, mapOf("network" to UciPackage("network", listOf(s)))).isEmpty())
        assertEquals(1, PlanEngine.verify(plan.sections, mapOf("network" to UciPackage("network", listOf(sec("interface", "lan", "proto" to "static"))))).size)
    }

    @Test fun newLanIpIsDetected() {
        val dev = mapOf("network" to UciPackage("network", listOf(sec("interface", "lan", "ipaddr" to "192.168.1.1"))))
        val tpl = mapOf("network" to listOf(sec("interface", "lan", "ipaddr" to "10.0.0.1")))
        assertEquals("10.0.0.1", PlanEngine.newLanIp(PlanEngine.build(tpl, dev).sections))
        assertNull(PlanEngine.newLanIp(emptyList()))
    }

    @Test fun backupHashDetectsTampering() {
        val info = DeviceInfo("h", "m", "b", "OpenWrt", "23.05.3", "r", "t", "k", 0, true)
        val b = Backup.create("1", "1.2.3.4", info, mapOf("network" to "config interface 'lan'"))
        assertTrue(b.intact)
        assertFalse(b.copy(packages = mapOf("network" to "changed")).intact)
    }

    @Test fun compatLevels() {
        val info = DeviceInfo("h", "m", "board-a", "OpenWrt", "23.05.3", "r", "t", "k", 0, true)
        val t = Template("1", "t", 0, 0, "board-a", "m", "OpenWrt", "23.05.2", false, emptyMap())
        assertEquals(Level.OK, Compat.check(t, info).level)
        assertEquals(Level.WARN, Compat.check(t.copy(board = "board-b"), info).level)
        assertEquals(Level.WARN, Compat.check(t.copy(version = "22.03.5"), info).level)
        assertEquals(Level.BLOCK, Compat.check(t, info.copy(uid = 1000)).level)
        assertEquals(Level.BLOCK, Compat.check(t, info.copy(hasUci = false)).level)
    }
}
